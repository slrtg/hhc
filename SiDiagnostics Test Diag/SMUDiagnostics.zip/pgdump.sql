--
-- PostgreSQL database dump
--

SET statement_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = off;
SET check_function_bodies = false;
SET client_min_messages = warning;
SET escape_string_warning = off;

--
-- Name: plpgsql; Type: PROCEDURAL LANGUAGE; Schema: -; Owner: postgres
--

CREATE OR REPLACE PROCEDURAL LANGUAGE plpgsql;


ALTER PROCEDURAL LANGUAGE plpgsql OWNER TO postgres;

SET search_path = public, pg_catalog;

SET default_tablespace = '';

SET default_with_oids = false;

--
-- Name: authorised_client; Type: TABLE; Schema: public; Owner: postgres; Tablespace: 
--

CREATE TABLE authorised_client (
    client_id integer NOT NULL,
    ipaddress character varying(255) NOT NULL
);


ALTER TABLE public.authorised_client OWNER TO postgres;

--
-- Name: cluster_node; Type: TABLE; Schema: public; Owner: postgres; Tablespace: 
--

CREATE TABLE cluster_node (
    cluster_node_id integer NOT NULL,
    serverid integer NOT NULL,
    mercury boolean NOT NULL,
    ipaddress character varying(255) NOT NULL
);


ALTER TABLE public.cluster_node OWNER TO postgres;

--
-- Name: dns_server; Type: TABLE; Schema: public; Owner: postgres; Tablespace: 
--

CREATE TABLE dns_server (
    dns_server_id integer NOT NULL,
    server character varying(255) NOT NULL
);


ALTER TABLE public.dns_server OWNER TO postgres;

--
-- Name: engenio_seq_num; Type: TABLE; Schema: public; Owner: postgres; Tablespace: 
--

CREATE TABLE engenio_seq_num (
    seq_num_db_id bigint NOT NULL,
    wwn character varying(255) NOT NULL,
    seqnum bigint NOT NULL
);


ALTER TABLE public.engenio_seq_num OWNER TO postgres;

--
-- Name: etc_host; Type: TABLE; Schema: public; Owner: postgres; Tablespace: 
--

CREATE TABLE etc_host (
    etc_host_id integer NOT NULL,
    host_ip character varying(255) NOT NULL,
    hostname character varying(255)
);


ALTER TABLE public.etc_host OWNER TO postgres;

--
-- Name: etc_host_alias; Type: TABLE; Schema: public; Owner: postgres; Tablespace: 
--

CREATE TABLE etc_host_alias (
    etc_host_alias_id integer NOT NULL,
    aliashostname character varying(255) NOT NULL,
    etc_host_id integer NOT NULL
);


ALTER TABLE public.etc_host_alias OWNER TO postgres;

--
-- Name: ethernet_interface; Type: TABLE; Schema: public; Owner: postgres; Tablespace: 
--

CREATE TABLE ethernet_interface (
    interface_id integer NOT NULL,
    interfacename character varying(255) NOT NULL,
    enabled boolean NOT NULL,
    ipaddress character varying(255) NOT NULL,
    netmask character varying(255) NOT NULL,
    gateway character varying(255) NOT NULL,
    enableipv6 boolean DEFAULT false,
    autoconfipv6 integer DEFAULT 0,
    ipaddress6 character varying(255),
    gateway6 character varying(255),
    dhcpipv4 boolean DEFAULT false
);


ALTER TABLE public.ethernet_interface OWNER TO postgres;

--
-- Name: evs_ip; Type: TABLE; Schema: public; Owner: postgres; Tablespace: 
--

CREATE TABLE evs_ip (
    evs_ip_db_id integer NOT NULL,
    serverid integer NOT NULL,
    evsid integer NOT NULL,
    ip character varying(255) NOT NULL,
    mask character varying(255) NOT NULL,
    port character varying(255) NOT NULL
);


ALTER TABLE public.evs_ip OWNER TO postgres;

--
-- Name: evs_name; Type: TABLE; Schema: public; Owner: postgres; Tablespace: 
--

CREATE TABLE evs_name (
    evs_name_db_id integer NOT NULL,
    serverid integer NOT NULL,
    evsid integer NOT NULL,
    name character varying(255) NOT NULL
);


ALTER TABLE public.evs_name OWNER TO postgres;

--
-- Name: fcswitch; Type: TABLE; Schema: public; Owner: postgres; Tablespace: 
--

CREATE TABLE fcswitch (
    switch_id bigint NOT NULL,
    name character varying(30) NOT NULL,
    address character varying(255) NOT NULL,
    protocol integer NOT NULL,
    port integer NOT NULL,
    username character varying(15),
    password character varying(40),
    url character varying(255)
);


ALTER TABLE public.fcswitch OWNER TO postgres;

--
-- Name: fcswitch_servers; Type: TABLE; Schema: public; Owner: postgres; Tablespace: 
--

CREATE TABLE fcswitch_servers (
    switch_id bigint NOT NULL,
    elt integer
);


ALTER TABLE public.fcswitch_servers OWNER TO postgres;

--
-- Name: file_system; Type: TABLE; Schema: public; Owner: postgres; Tablespace: 
--

CREATE TABLE file_system (
    fs_id_db_id integer NOT NULL,
    serverid integer NOT NULL,
    evsid integer NOT NULL,
    label character varying(255) NOT NULL,
    devid integer NOT NULL,
    permid numeric(21,0) NOT NULL,
    filesystemid character varying(255) NOT NULL,
    spanpermid numeric(21,0) NOT NULL,
    isreadcache boolean
);


ALTER TABLE public.file_system OWNER TO postgres;

--
-- Name: fs_item_relocation; Type: TABLE; Schema: public; Owner: postgres; Tablespace: 
--

CREATE TABLE fs_item_relocation (
    fs_relocation_item_db_id integer NOT NULL,
    fsrelocationobjid integer NOT NULL,
    type integer NOT NULL,
    itemid integer NOT NULL,
    name character varying(255) NOT NULL
);


ALTER TABLE public.fs_item_relocation OWNER TO postgres;

--
-- Name: fs_relocation; Type: TABLE; Schema: public; Owner: postgres; Tablespace: 
--

CREATE TABLE fs_relocation (
    fs_relocation_db_id integer NOT NULL,
    serverid integer NOT NULL,
    oldevsid integer NOT NULL,
    newevsid integer NOT NULL,
    fspermid character varying(255) NOT NULL,
    fslabel character varying(255) NOT NULL,
    currentstate integer NOT NULL,
    currentitemindex integer NOT NULL,
    stalled boolean NOT NULL,
    errmsg character varying(255),
    setiscsidomainname boolean
);


ALTER TABLE public.fs_relocation OWNER TO postgres;

--
-- Name: hibernate_sequence; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE hibernate_sequence
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.hibernate_sequence OWNER TO postgres;

--
-- Name: hibernate_sequence; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('hibernate_sequence', 1275678, true);


--
-- Name: hicommand; Type: TABLE; Schema: public; Owner: postgres; Tablespace: 
--

CREATE TABLE hicommand (
    hicommand_id bigint NOT NULL,
    address character varying(255) NOT NULL,
    username character varying(15) NOT NULL,
    password character varying(40) NOT NULL,
    port integer NOT NULL,
    lastupdate bigint NOT NULL
);


ALTER TABLE public.hicommand OWNER TO postgres;

--
-- Name: hicommand_servers; Type: TABLE; Schema: public; Owner: postgres; Tablespace: 
--

CREATE TABLE hicommand_servers (
    hicommand_id bigint NOT NULL,
    elt integer
);


ALTER TABLE public.hicommand_servers OWNER TO postgres;

--
-- Name: host_config; Type: TABLE; Schema: public; Owner: postgres; Tablespace: 
--

CREATE TABLE host_config (
    host_config_id integer NOT NULL,
    hostname character varying(255) NOT NULL,
    domain character varying(255) NOT NULL,
    enableipv6 boolean DEFAULT false,
    autoconfipv6 integer DEFAULT 0,
    gateway6 character varying(255) DEFAULT ''::character varying
);


ALTER TABLE public.host_config OWNER TO postgres;

--
-- Name: ip_filter_status; Type: TABLE; Schema: public; Owner: postgres; Tablespace: 
--

CREATE TABLE ip_filter_status (
    config_id integer NOT NULL,
    ipfilteringenabled boolean NOT NULL
);


ALTER TABLE public.ip_filter_status OWNER TO postgres;

--
-- Name: luid; Type: TABLE; Schema: public; Owner: postgres; Tablespace: 
--

CREATE TABLE luid (
    luid_db_id integer NOT NULL,
    serverid integer NOT NULL,
    evsid integer NOT NULL,
    luid character varying(255) NOT NULL
);


ALTER TABLE public.luid OWNER TO postgres;

--
-- Name: name_search; Type: TABLE; Schema: public; Owner: postgres; Tablespace: 
--

CREATE TABLE name_search (
    name_search_id integer NOT NULL,
    prefix character varying(255) NOT NULL
);


ALTER TABLE public.name_search OWNER TO postgres;

--
-- Name: nat_rule; Type: TABLE; Schema: public; Owner: postgres; Tablespace: 
--

CREATE TABLE nat_rule (
    nat_rule_id integer NOT NULL,
    interfacename character varying(255) NOT NULL,
    trojanport integer NOT NULL,
    ipaddress character varying(255) NOT NULL,
    destport integer NOT NULL
);


ALTER TABLE public.nat_rule OWNER TO postgres;

--
-- Name: ntp_server; Type: TABLE; Schema: public; Owner: postgres; Tablespace: 
--

CREATE TABLE ntp_server (
    ntp_server_id integer NOT NULL,
    ipaddress character varying(255) NOT NULL
);


ALTER TABLE public.ntp_server OWNER TO postgres;

--
-- Name: pdm_path; Type: TABLE; Schema: public; Owner: postgres; Tablespace: 
--

CREATE TABLE pdm_path (
    pdm_path_id integer NOT NULL,
    serverid integer NOT NULL,
    primaryfs integer NOT NULL,
    primaryvivol character varying(255) NOT NULL,
    secondaryfs integer NOT NULL,
    evsid integer NOT NULL
);


ALTER TABLE public.pdm_path OWNER TO postgres;

--
-- Name: perm_id; Type: TABLE; Schema: public; Owner: postgres; Tablespace: 
--

CREATE TABLE perm_id (
    perm_id_db_id integer NOT NULL,
    serverid integer NOT NULL,
    evsid integer NOT NULL,
    permid character varying(255) NOT NULL
);


ALTER TABLE public.perm_id OWNER TO postgres;

--
-- Name: radius_servers; Type: TABLE; Schema: public; Owner: postgres; Tablespace: 
--

CREATE TABLE radius_servers (
    radius_server_id integer NOT NULL,
    radius_server_name character varying(1200) NOT NULL,
    radius_server_port integer NOT NULL,
    radius_server_protocol smallint DEFAULT 0,
    radius_server_shared_secret character varying(256) NOT NULL,
    radius_server_retry_count integer NOT NULL,
    radius_server_timeout integer NOT NULL,
    radius_server_priority integer NOT NULL
);


ALTER TABLE public.radius_servers OWNER TO postgres;

--
-- Name: server_name; Type: TABLE; Schema: public; Owner: postgres; Tablespace: 
--

CREATE TABLE server_name (
    server_name_db_id integer NOT NULL,
    serverid integer NOT NULL,
    name character varying(255) NOT NULL
);


ALTER TABLE public.server_name OWNER TO postgres;

--
-- Name: service_port; Type: TABLE; Schema: public; Owner: postgres; Tablespace: 
--

CREATE TABLE service_port (
    service_port_id integer NOT NULL,
    service integer NOT NULL,
    port integer NOT NULL,
    protocol integer NOT NULL
);


ALTER TABLE public.service_port OWNER TO postgres;

--
-- Name: smtp_server; Type: TABLE; Schema: public; Owner: postgres; Tablespace: 
--

CREATE TABLE smtp_server (
    smtp_server_id integer NOT NULL,
    hostname character varying(255) NOT NULL
);


ALTER TABLE public.smtp_server OWNER TO postgres;

--
-- Name: smu_email_profile; Type: TABLE; Schema: public; Owner: postgres; Tablespace: 
--

CREATE TABLE smu_email_profile (
    smu_email_profile_id bigint NOT NULL,
    profilename character varying(255) NOT NULL,
    server integer NOT NULL,
    fromfield character varying(255) NOT NULL,
    dailystatusemailtime character varying(5) NOT NULL,
    dailystatusemailenabled boolean NOT NULL,
    dailystatusemailsubject character varying(255) NOT NULL,
    dailystatusemailhtml boolean NOT NULL,
    monthlycallhomeemailenabled boolean,
    disabled boolean
);


ALTER TABLE public.smu_email_profile OWNER TO postgres;

--
-- Name: smu_email_recipients; Type: TABLE; Schema: public; Owner: postgres; Tablespace: 
--

CREATE TABLE smu_email_recipients (
    smu_email_profile_id bigint NOT NULL,
    elt character varying(255)
);


ALTER TABLE public.smu_email_recipients OWNER TO postgres;

--
-- Name: snap_rule; Type: TABLE; Schema: public; Owner: postgres; Tablespace: 
--

CREATE TABLE snap_rule (
    snap_rule_db_id integer NOT NULL,
    serverid integer NOT NULL,
    evsid integer NOT NULL,
    name character varying(255) NOT NULL,
    queuesize integer NOT NULL,
    permid character varying(255) NOT NULL
);


ALTER TABLE public.snap_rule OWNER TO postgres;

--
-- Name: snapshot_rule; Type: TABLE; Schema: public; Owner: postgres; Tablespace: 
--

CREATE TABLE snapshot_rule (
    snapshot_rule_db_id integer NOT NULL,
    serverid integer NOT NULL,
    evsid integer NOT NULL,
    name character varying(255) NOT NULL,
    queuesize integer NOT NULL,
    devid integer NOT NULL
);


ALTER TABLE public.snapshot_rule OWNER TO postgres;

--
-- Name: snapshot_schedule; Type: TABLE; Schema: public; Owner: postgres; Tablespace: 
--

CREATE TABLE snapshot_schedule (
    snapshot_schedule_db_id integer NOT NULL,
    snapshotruleid integer NOT NULL,
    maillist character varying(255) NOT NULL,
    commandlist character varying(255) NOT NULL,
    datetimespec character varying(255) NOT NULL
);


ALTER TABLE public.snapshot_schedule OWNER TO postgres;

--
-- Name: span; Type: TABLE; Schema: public; Owner: postgres; Tablespace: 
--

CREATE TABLE span (
    span_id_db_id integer NOT NULL,
    serverid integer NOT NULL,
    label character varying(255) NOT NULL,
    permid numeric(21,0) NOT NULL,
    allowfsondifferentevs boolean NOT NULL,
    belongstothiscluster boolean NOT NULL,
    noofsdsinspan integer NOT NULL,
    lastupdated date
);


ALTER TABLE public.span OWNER TO postgres;

--
-- Name: standby_smu; Type: TABLE; Schema: public; Owner: postgres; Tablespace: 
--

CREATE TABLE standby_smu (
    standby_smu_id integer NOT NULL,
    hostname character varying(255) NOT NULL
);


ALTER TABLE public.standby_smu OWNER TO postgres;

--
-- Name: system_drive; Type: TABLE; Schema: public; Owner: postgres; Tablespace: 
--

CREATE TABLE system_drive (
    sd_db_id integer NOT NULL,
    serverid integer NOT NULL,
    label character varying(255) NOT NULL,
    devid integer NOT NULL,
    luid character varying(255) NOT NULL,
    manufacturer character varying(255) NOT NULL,
    model character varying(255) NOT NULL,
    manufacturerid integer NOT NULL,
    vendormanufacturerid numeric(21,0),
    siteid integer,
    spanpermid numeric(21,0) NOT NULL
);


ALTER TABLE public.system_drive OWNER TO postgres;

--
-- Name: time_zone; Type: TABLE; Schema: public; Owner: postgres; Tablespace: 
--

CREATE TABLE time_zone (
    time_zone_id integer NOT NULL,
    timezone character varying(255) NOT NULL
);


ALTER TABLE public.time_zone OWNER TO postgres;

--
-- Name: user_accessibility; Type: TABLE; Schema: public; Owner: postgres; Tablespace: 
--

CREATE TABLE user_accessibility (
    user_accessibility_id integer NOT NULL,
    user_name character varying(100) NOT NULL,
    server_id integer,
    evs_id integer,
    vivol_name character varying(128)
);


ALTER TABLE public.user_accessibility OWNER TO postgres;

--
-- Name: user_roles; Type: TABLE; Schema: public; Owner: postgres; Tablespace: 
--

CREATE TABLE user_roles (
    user_role_id integer NOT NULL,
    user_name character varying(100) NOT NULL,
    role_name character varying(15) NOT NULL
);


ALTER TABLE public.user_roles OWNER TO postgres;

--
-- Name: users; Type: TABLE; Schema: public; Owner: postgres; Tablespace: 
--

CREATE TABLE users (
    user_id integer NOT NULL,
    user_name character varying(100) NOT NULL,
    user_pass character varying(200) NOT NULL,
    user_level integer NOT NULL,
    flags integer NOT NULL,
    user_type smallint DEFAULT 0
);


ALTER TABLE public.users OWNER TO postgres;

--
-- Data for Name: authorised_client; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY authorised_client (client_id, ipaddress) FROM stdin;
\.


--
-- Data for Name: cluster_node; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY cluster_node (cluster_node_id, serverid, mercury, ipaddress) FROM stdin;
13	1	t	192.0.2.200
115474	2	t	192.0.2.11
797964	2	t	192.0.2.10
\.


--
-- Data for Name: dns_server; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY dns_server (dns_server_id, server) FROM stdin;
115419	172.17.7.232
115420	137.72.16.9
\.


--
-- Data for Name: engenio_seq_num; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY engenio_seq_num (seq_num_db_id, wwn, seqnum) FROM stdin;
\.


--
-- Data for Name: etc_host; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY etc_host (etc_host_id, host_ip, hostname) FROM stdin;
\.


--
-- Data for Name: etc_host_alias; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY etc_host_alias (etc_host_alias_id, aliashostname, etc_host_id) FROM stdin;
\.


--
-- Data for Name: ethernet_interface; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY ethernet_interface (interface_id, interfacename, enabled, ipaddress, netmask, gateway, enableipv6, autoconfipv6, ipaddress6, gateway6, dhcpipv4) FROM stdin;
10	eth0	t	172.17.2.25	255.255.0.0	172.17.0.253	f	0	\N	\N	f
11	eth1	t	192.0.2.1	255.255.255.0	192.0.2.1	f	0	\N	\N	f
\.


--
-- Data for Name: evs_ip; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY evs_ip (evs_ip_db_id, serverid, evsid, ip, mask, port) FROM stdin;
\.


--
-- Data for Name: evs_name; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY evs_name (evs_name_db_id, serverid, evsid, name) FROM stdin;
1275625	2	1	charm-01
1275626	2	2	photon-02
1275627	2	3	rnd-clufs-03
1275629	2	4	mohawk-04
1275630	2	5	dagger-05
1275631	2	6	smore-06
1275632	2	7	hou-hnasprd-01
1275633	2	8	bos-hnas-01
1275634	2	9	rnd-clufs-10
\.


--
-- Data for Name: fcswitch; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY fcswitch (switch_id, name, address, protocol, port, username, password, url) FROM stdin;
\.


--
-- Data for Name: fcswitch_servers; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY fcswitch_servers (switch_id, elt) FROM stdin;
\.


--
-- Data for Name: file_system; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY file_system (fs_id_db_id, serverid, evsid, label, devid, permid, filesystemid, spanpermid, isreadcache) FROM stdin;
1275635	2	8	bos-hnas-01-sp01-fs01	1032	9807195757388551263	881A2894A1DCD45F0000000000000000	9813686305442517874	f
1275636	2	6	smore-06-sp02-fs01	1030	9813669321095848573	88312840A311227D0000000000000000	9813686339473918740	f
1275637	2	5	dagger-05-sp02-fs01	1029	9813669419708912029	8831285798DD119D0000000000000000	9813686339473918740	f
1275638	2	1	charm-01-sp01-fs01	1025	9813670747702295338	8831298CCB6FFB2A0000000000000000	9813686305442517874	f
1275639	2	4	mohawk-04-sp02-fs01	1027	9813670871601698584	883129A9A46AD7180000000000000000	9813686339473918740	f
1275640	2	4	mohawk-04-sp02-fs02	1028	9813670896942527190	883129AF8AD932D60000000000000000	9813686339473918740	f
1275641	2	2	photon-02-sp01-fs01	1026	9813670926986797359	883129B689A0612F0000000000000000	9813686305442517874	f
1275642	2	3	rnd-clufs-03-sp01-fs01	1024	9813685299796219930	883136C8F7D3981A0000000000000000	9813686305442517874	f
1275643	2	9	rnd-clufs-10-sp01-fs01	1033	9814919549275681171	88359954119D31930000000000000000	9813686305442517874	f
1275644	2	7	hou-hnasprd-01-sp02-fs01	1031	9831931652717578941	887209BF10268ABD0000000000000000	9813686339473918740	f
\.


--
-- Data for Name: fs_item_relocation; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY fs_item_relocation (fs_relocation_item_db_id, fsrelocationobjid, type, itemid, name) FROM stdin;
\.


--
-- Data for Name: fs_relocation; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY fs_relocation (fs_relocation_db_id, serverid, oldevsid, newevsid, fspermid, fslabel, currentstate, currentitemindex, stalled, errmsg, setiscsidomainname) FROM stdin;
\.


--
-- Data for Name: hicommand; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY hicommand (hicommand_id, address, username, password, port, lastupdate) FROM stdin;
478038	phx-hdshcs-01.adprod.bmc.com	system	manager	2001	1409644824299
\.


--
-- Data for Name: hicommand_servers; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY hicommand_servers (hicommand_id, elt) FROM stdin;
478038	0
\.


--
-- Data for Name: host_config; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY host_config (host_config_id, hostname, domain, enableipv6, autoconfipv6, gateway6) FROM stdin;
8	hou-hds-smu	bmc.com	f	0	
\.


--
-- Data for Name: ip_filter_status; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY ip_filter_status (config_id, ipfilteringenabled) FROM stdin;
5	f
\.


--
-- Data for Name: luid; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY luid (luid_db_id, serverid, evsid, luid) FROM stdin;
\.


--
-- Data for Name: name_search; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY name_search (name_search_id, prefix) FROM stdin;
115421	bmc.com
\.


--
-- Data for Name: nat_rule; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY nat_rule (nat_rule_id, interfacename, trojanport, ipaddress, destport) FROM stdin;
31	eth0	28002	192.0.2.2	8443
32	eth0	28003	192.0.2.3	8443
\.


--
-- Data for Name: ntp_server; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY ntp_server (ntp_server_id, ipaddress) FROM stdin;
876353	ntp.bmc.com
876354	ntp2.bmc.com
876355	ntp3.bmc.com
\.


--
-- Data for Name: pdm_path; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY pdm_path (pdm_path_id, serverid, primaryfs, primaryvivol, secondaryfs, evsid) FROM stdin;
\.


--
-- Data for Name: perm_id; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY perm_id (perm_id_db_id, serverid, evsid, permid) FROM stdin;
\.


--
-- Data for Name: radius_servers; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY radius_servers (radius_server_id, radius_server_name, radius_server_port, radius_server_protocol, radius_server_shared_secret, radius_server_retry_count, radius_server_timeout, radius_server_priority) FROM stdin;
\.


--
-- Data for Name: server_name; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY server_name (server_name_db_id, serverid, name) FROM stdin;
115472	1	testhost
1275678	2	BMC-HNAS
\.


--
-- Data for Name: service_port; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY service_port (service_port_id, service, port, protocol) FROM stdin;
\.


--
-- Data for Name: smtp_server; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY smtp_server (smtp_server_id, hostname) FROM stdin;
2151	mailhost.bmc.com
\.


--
-- Data for Name: smu_email_profile; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY smu_email_profile (smu_email_profile_id, profilename, server, fromfield, dailystatusemailtime, dailystatusemailenabled, dailystatusemailsubject, dailystatusemailhtml, monthlycallhomeemailenabled, disabled) FROM stdin;
1134343	HNAS-Alerts	2		08:30	t	Daily Summary	t	t	f
\.


--
-- Data for Name: smu_email_recipients; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY smu_email_recipients (smu_email_profile_id, elt) FROM stdin;
1134343	John_Baran@bmc.com
1134343	Frank_Figone@bmc.com
1134343	Tony_Rivera@bmc.com
\.


--
-- Data for Name: snap_rule; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY snap_rule (snap_rule_db_id, serverid, evsid, name, queuesize, permid) FROM stdin;
1275628	2	3	Rule1	4	9813685299796219930
\.


--
-- Data for Name: snapshot_rule; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY snapshot_rule (snapshot_rule_db_id, serverid, evsid, name, queuesize, devid) FROM stdin;
\.


--
-- Data for Name: snapshot_schedule; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY snapshot_schedule (snapshot_schedule_db_id, snapshotruleid, maillist, commandlist, datetimespec) FROM stdin;
\.


--
-- Data for Name: span; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY span (span_id_db_id, serverid, label, permid, allowfsondifferentevs, belongstothiscluster, noofsdsinspan, lastupdated) FROM stdin;
1266843	2	SP-01	9813686305442517874	t	t	4	2014-08-29
1266844	2	SP-02	9813686339473918740	t	t	4	2014-08-29
\.


--
-- Data for Name: standby_smu; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY standby_smu (standby_smu_id, hostname) FROM stdin;
\.


--
-- Data for Name: system_drive; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY system_drive (sd_db_id, serverid, label, devid, luid, manufacturer, model, manufacturerid, vendormanufacturerid, siteid, spanpermid) FROM stdin;
115668	2	66510	0	03 01 00 60 06 0e 80 16 03 ce 00 00 01 03 ce 00 00 70 00	HITACHI	OPEN-V	0	50528275	0	9813686305442517874
115669	2	66510	1	03 01 00 60 06 0e 80 16 03 ce 00 00 01 03 ce 00 00 70 01	HITACHI	OPEN-V	0	50528275	0	9813686305442517874
115670	2	66510	2	03 01 00 60 06 0e 80 16 03 ce 00 00 01 03 ce 00 00 70 02	HITACHI	OPEN-V	0	50528275	0	9813686305442517874
115671	2	66510	3	03 01 00 60 06 0e 80 16 03 ce 00 00 01 03 ce 00 00 70 03	HITACHI	OPEN-V	0	50528275	0	9813686305442517874
115672	2	66510	4	03 01 00 60 06 0e 80 16 03 ce 00 00 01 03 ce 00 00 70 04	HITACHI	OPEN-V	0	50528275	0	9813686339473918740
115673	2	66510	5	03 01 00 60 06 0e 80 16 03 ce 00 00 01 03 ce 00 00 70 05	HITACHI	OPEN-V	0	50528275	0	9813686339473918740
115674	2	66510	6	03 01 00 60 06 0e 80 16 03 ce 00 00 01 03 ce 00 00 70 06	HITACHI	OPEN-V	0	50528275	0	9813686339473918740
115675	2	66510	7	03 01 00 60 06 0e 80 16 03 ce 00 00 01 03 ce 00 00 70 07	HITACHI	OPEN-V	0	50528275	0	9813686339473918740
\.


--
-- Data for Name: time_zone; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY time_zone (time_zone_id, timezone) FROM stdin;
876352	America/Chicago
\.


--
-- Data for Name: user_accessibility; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY user_accessibility (user_accessibility_id, user_name, server_id, evs_id, vivol_name) FROM stdin;
526261	Vscan	0	255	
\.


--
-- Data for Name: user_roles; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY user_roles (user_role_id, user_name, role_name) FROM stdin;
2	admin	admin
4	bapush	uploader
2108	trivera	admin
245051	jbaran	admin
367498	ffigone	admin
526260	Vscan	admin
\.


--
-- Data for Name: users; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY users (user_id, user_name, user_pass, user_level, flags, user_type) FROM stdin;
1	admin	$6$fFB7YLI8laD9qs/P$GCxZG3lRfburpbsK6ALoIpPmI6KPy8MFtEyi6oWG7MCTUFai6OwSJOK2bTCd5Qjk470UZwuNmYVAZkHKE0VLb1	1	0	0
3	bapush	$6$NhpYvuRuTZkULkjM$dl1yzs77dVOpM2F0aTlKpn3iwli0ZJL5nrhpGwVXjYKLbge8gVdhuQqMtkaAslwRysa5hHSKT3X.5ot76az2l/	1	1	0
2107	trivera	$6$UEA9Ag0RzkFd86IO$c0/f1FSF4XtQPyL5wJiuWtWH3wZ9OItLLlOhAtzaMdMO8qy7/rFmHyfLBozQ91wcwpn2I4fMG3E/9hEE8VJL4.	1	16	0
367497	ffigone	$6$YMK3B3SOpCbVdgUc$gmvWw8.q9hV4WYUp8TbujaO8WIVJyD1fkNvDdQZUD9ILE8frTyR2m/ODIpc0AHc9zukg8Ak/HTMG.a/dYna941	1	16	0
526259	Vscan	$6$N21AifiRCAHrdcte$1O7CW2KmmGYQBo9vfvGhFPce8kcW0dkWvuV8EVILw5NB1iZwOdHFzqgWrdZnR00TSvTDuT8DXkIiiMHVDaTTz0	2	0	0
245050	jbaran	$6$LI97I/brGtMXCnvh$I4kFNbytneo6ddX43e/MRrA9CnFXjbJ/Bn45E1X9Vsx93wcffbeHyT2./tQKrPw/O/EXhfLlYc0khHfN/TZiM1	1	16	0
\.


--
-- Name: authorised_client_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres; Tablespace: 
--

ALTER TABLE ONLY authorised_client
    ADD CONSTRAINT authorised_client_pkey PRIMARY KEY (client_id);


--
-- Name: cluster_node_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres; Tablespace: 
--

ALTER TABLE ONLY cluster_node
    ADD CONSTRAINT cluster_node_pkey PRIMARY KEY (cluster_node_id);


--
-- Name: dns_server_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres; Tablespace: 
--

ALTER TABLE ONLY dns_server
    ADD CONSTRAINT dns_server_pkey PRIMARY KEY (dns_server_id);


--
-- Name: engenio_seq_num_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres; Tablespace: 
--

ALTER TABLE ONLY engenio_seq_num
    ADD CONSTRAINT engenio_seq_num_pkey PRIMARY KEY (seq_num_db_id);


--
-- Name: engenio_seq_num_wwn_key; Type: CONSTRAINT; Schema: public; Owner: postgres; Tablespace: 
--

ALTER TABLE ONLY engenio_seq_num
    ADD CONSTRAINT engenio_seq_num_wwn_key UNIQUE (wwn);


--
-- Name: etc_host_alias_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres; Tablespace: 
--

ALTER TABLE ONLY etc_host_alias
    ADD CONSTRAINT etc_host_alias_pkey PRIMARY KEY (etc_host_alias_id);


--
-- Name: etc_host_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres; Tablespace: 
--

ALTER TABLE ONLY etc_host
    ADD CONSTRAINT etc_host_pkey PRIMARY KEY (etc_host_id);


--
-- Name: ethernet_interface_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres; Tablespace: 
--

ALTER TABLE ONLY ethernet_interface
    ADD CONSTRAINT ethernet_interface_pkey PRIMARY KEY (interface_id);


--
-- Name: evs_ip_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres; Tablespace: 
--

ALTER TABLE ONLY evs_ip
    ADD CONSTRAINT evs_ip_pkey PRIMARY KEY (evs_ip_db_id);


--
-- Name: evs_name_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres; Tablespace: 
--

ALTER TABLE ONLY evs_name
    ADD CONSTRAINT evs_name_pkey PRIMARY KEY (evs_name_db_id);


--
-- Name: fcswitch_address_key; Type: CONSTRAINT; Schema: public; Owner: postgres; Tablespace: 
--

ALTER TABLE ONLY fcswitch
    ADD CONSTRAINT fcswitch_address_key UNIQUE (address);


--
-- Name: fcswitch_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres; Tablespace: 
--

ALTER TABLE ONLY fcswitch
    ADD CONSTRAINT fcswitch_pkey PRIMARY KEY (switch_id);


--
-- Name: file_system_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres; Tablespace: 
--

ALTER TABLE ONLY file_system
    ADD CONSTRAINT file_system_pkey PRIMARY KEY (fs_id_db_id);


--
-- Name: fs_item_relocation_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres; Tablespace: 
--

ALTER TABLE ONLY fs_item_relocation
    ADD CONSTRAINT fs_item_relocation_pkey PRIMARY KEY (fs_relocation_item_db_id);


--
-- Name: fs_relocation_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres; Tablespace: 
--

ALTER TABLE ONLY fs_relocation
    ADD CONSTRAINT fs_relocation_pkey PRIMARY KEY (fs_relocation_db_id);


--
-- Name: hicommand_address_key; Type: CONSTRAINT; Schema: public; Owner: postgres; Tablespace: 
--

ALTER TABLE ONLY hicommand
    ADD CONSTRAINT hicommand_address_key UNIQUE (address);


--
-- Name: hicommand_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres; Tablespace: 
--

ALTER TABLE ONLY hicommand
    ADD CONSTRAINT hicommand_pkey PRIMARY KEY (hicommand_id);


--
-- Name: host_config_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres; Tablespace: 
--

ALTER TABLE ONLY host_config
    ADD CONSTRAINT host_config_pkey PRIMARY KEY (host_config_id);


--
-- Name: ip_filter_status_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres; Tablespace: 
--

ALTER TABLE ONLY ip_filter_status
    ADD CONSTRAINT ip_filter_status_pkey PRIMARY KEY (config_id);


--
-- Name: luid_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres; Tablespace: 
--

ALTER TABLE ONLY luid
    ADD CONSTRAINT luid_pkey PRIMARY KEY (luid_db_id);


--
-- Name: name_search_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres; Tablespace: 
--

ALTER TABLE ONLY name_search
    ADD CONSTRAINT name_search_pkey PRIMARY KEY (name_search_id);


--
-- Name: nat_rule_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres; Tablespace: 
--

ALTER TABLE ONLY nat_rule
    ADD CONSTRAINT nat_rule_pkey PRIMARY KEY (nat_rule_id);


--
-- Name: ntp_server_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres; Tablespace: 
--

ALTER TABLE ONLY ntp_server
    ADD CONSTRAINT ntp_server_pkey PRIMARY KEY (ntp_server_id);


--
-- Name: pdm_path_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres; Tablespace: 
--

ALTER TABLE ONLY pdm_path
    ADD CONSTRAINT pdm_path_pkey PRIMARY KEY (pdm_path_id);


--
-- Name: perm_id_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres; Tablespace: 
--

ALTER TABLE ONLY perm_id
    ADD CONSTRAINT perm_id_pkey PRIMARY KEY (perm_id_db_id);


--
-- Name: radius_servers_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres; Tablespace: 
--

ALTER TABLE ONLY radius_servers
    ADD CONSTRAINT radius_servers_pkey PRIMARY KEY (radius_server_id);


--
-- Name: radius_servers_radius_server_name_radius_server_protocol_key; Type: CONSTRAINT; Schema: public; Owner: postgres; Tablespace: 
--

ALTER TABLE ONLY radius_servers
    ADD CONSTRAINT radius_servers_radius_server_name_radius_server_protocol_key UNIQUE (radius_server_name, radius_server_protocol);


--
-- Name: radius_servers_radius_server_priority_key; Type: CONSTRAINT; Schema: public; Owner: postgres; Tablespace: 
--

ALTER TABLE ONLY radius_servers
    ADD CONSTRAINT radius_servers_radius_server_priority_key UNIQUE (radius_server_priority);


--
-- Name: server_name_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres; Tablespace: 
--

ALTER TABLE ONLY server_name
    ADD CONSTRAINT server_name_pkey PRIMARY KEY (server_name_db_id);


--
-- Name: service_port_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres; Tablespace: 
--

ALTER TABLE ONLY service_port
    ADD CONSTRAINT service_port_pkey PRIMARY KEY (service_port_id);


--
-- Name: service_port_service_key; Type: CONSTRAINT; Schema: public; Owner: postgres; Tablespace: 
--

ALTER TABLE ONLY service_port
    ADD CONSTRAINT service_port_service_key UNIQUE (service);


--
-- Name: smtp_server_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres; Tablespace: 
--

ALTER TABLE ONLY smtp_server
    ADD CONSTRAINT smtp_server_pkey PRIMARY KEY (smtp_server_id);


--
-- Name: smu_email_profile_dailystatusemailtime_key; Type: CONSTRAINT; Schema: public; Owner: postgres; Tablespace: 
--

ALTER TABLE ONLY smu_email_profile
    ADD CONSTRAINT smu_email_profile_dailystatusemailtime_key UNIQUE (dailystatusemailtime);


--
-- Name: smu_email_profile_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres; Tablespace: 
--

ALTER TABLE ONLY smu_email_profile
    ADD CONSTRAINT smu_email_profile_pkey PRIMARY KEY (smu_email_profile_id);


--
-- Name: smu_email_profile_profilename_key; Type: CONSTRAINT; Schema: public; Owner: postgres; Tablespace: 
--

ALTER TABLE ONLY smu_email_profile
    ADD CONSTRAINT smu_email_profile_profilename_key UNIQUE (profilename);


--
-- Name: snap_rule_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres; Tablespace: 
--

ALTER TABLE ONLY snap_rule
    ADD CONSTRAINT snap_rule_pkey PRIMARY KEY (snap_rule_db_id);


--
-- Name: snapshot_rule_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres; Tablespace: 
--

ALTER TABLE ONLY snapshot_rule
    ADD CONSTRAINT snapshot_rule_pkey PRIMARY KEY (snapshot_rule_db_id);


--
-- Name: snapshot_schedule_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres; Tablespace: 
--

ALTER TABLE ONLY snapshot_schedule
    ADD CONSTRAINT snapshot_schedule_pkey PRIMARY KEY (snapshot_schedule_db_id);


--
-- Name: span_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres; Tablespace: 
--

ALTER TABLE ONLY span
    ADD CONSTRAINT span_pkey PRIMARY KEY (span_id_db_id);


--
-- Name: standby_smu_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres; Tablespace: 
--

ALTER TABLE ONLY standby_smu
    ADD CONSTRAINT standby_smu_pkey PRIMARY KEY (standby_smu_id);


--
-- Name: system_drive_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres; Tablespace: 
--

ALTER TABLE ONLY system_drive
    ADD CONSTRAINT system_drive_pkey PRIMARY KEY (sd_db_id);


--
-- Name: time_zone_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres; Tablespace: 
--

ALTER TABLE ONLY time_zone
    ADD CONSTRAINT time_zone_pkey PRIMARY KEY (time_zone_id);


--
-- Name: user_accessibility_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres; Tablespace: 
--

ALTER TABLE ONLY user_accessibility
    ADD CONSTRAINT user_accessibility_pkey PRIMARY KEY (user_accessibility_id);


--
-- Name: user_roles_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres; Tablespace: 
--

ALTER TABLE ONLY user_roles
    ADD CONSTRAINT user_roles_pkey PRIMARY KEY (user_role_id);


--
-- Name: user_roles_user_name_key; Type: CONSTRAINT; Schema: public; Owner: postgres; Tablespace: 
--

ALTER TABLE ONLY user_roles
    ADD CONSTRAINT user_roles_user_name_key UNIQUE (user_name);


--
-- Name: users_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres; Tablespace: 
--

ALTER TABLE ONLY users
    ADD CONSTRAINT users_pkey PRIMARY KEY (user_id);


--
-- Name: users_user_name_key; Type: CONSTRAINT; Schema: public; Owner: postgres; Tablespace: 
--

ALTER TABLE ONLY users
    ADD CONSTRAINT users_user_name_key UNIQUE (user_name);


--
-- Name: etc_host_ip; Type: INDEX; Schema: public; Owner: postgres; Tablespace: 
--

CREATE INDEX etc_host_ip ON etc_host USING btree (host_ip);


--
-- Name: fk1d0cf57b69bf1c08; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY hicommand_servers
    ADD CONSTRAINT fk1d0cf57b69bf1c08 FOREIGN KEY (hicommand_id) REFERENCES hicommand(hicommand_id);


--
-- Name: fk3c12d884a58c303; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY etc_host_alias
    ADD CONSTRAINT fk3c12d884a58c303 FOREIGN KEY (etc_host_id) REFERENCES etc_host(etc_host_id);


--
-- Name: fk4c072182335a3424; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY fcswitch_servers
    ADD CONSTRAINT fk4c072182335a3424 FOREIGN KEY (switch_id) REFERENCES fcswitch(switch_id);


--
-- Name: fk79d16861a8eac400; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY smu_email_recipients
    ADD CONSTRAINT fk79d16861a8eac400 FOREIGN KEY (smu_email_profile_id) REFERENCES smu_email_profile(smu_email_profile_id);


--
-- Name: public; Type: ACL; Schema: -; Owner: postgres
--

REVOKE ALL ON SCHEMA public FROM PUBLIC;
REVOKE ALL ON SCHEMA public FROM postgres;
GRANT ALL ON SCHEMA public TO postgres;
GRANT ALL ON SCHEMA public TO PUBLIC;


--
-- PostgreSQL database dump complete
--

